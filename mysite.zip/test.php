<?php
echo ("Hello world");
?>