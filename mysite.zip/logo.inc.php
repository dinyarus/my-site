<div class="logo">
	<img src="img/web-2.png" alt="php">
</div>