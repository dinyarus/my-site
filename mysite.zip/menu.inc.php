            <nav>
                <ul>
                    <li><a href="#"> Новости </a></li>
                    <li><a href="#"> Творчество </a></li>
                    <li><a href="#"> Фото </a></li>
                    <li><a href="#"> Ссылки </a></li>
                    <li><a href="#"> Контакты </a></li>
                </ul>    
            </nav>