<?php
$p = 'Добро пожаловать на мою страничку!';
?>

<?php
$forname = 'Денис';
$name = 'Владимирович';
$stadt = 'Москва';
$alt = '45';
?>

<?php
include 'main.php';
?>